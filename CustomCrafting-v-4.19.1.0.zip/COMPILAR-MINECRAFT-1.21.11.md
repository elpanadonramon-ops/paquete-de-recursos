# CustomCrafting 4.19.1.0 — preparación para Minecraft 1.21.11

Este código fuente se ha actualizado para apuntar a Paper API 1.21.11 y a la API declarada por `plugin.yml`.

## Requisitos
- JDK 21.
- IntelliJ IDEA con soporte Gradle.
- Conexión a Internet para resolver las dependencias Maven.

## Compilar en IntelliJ IDEA
1. Extrae todo el ZIP a una carpeta nueva.
2. Abre la carpeta raíz `CustomCrafting-v-4.19.1.0` como proyecto Gradle.
3. Selecciona JDK 21 para Gradle.
4. Espera a que termine la sincronización.
5. Ejecuta la tarea `:spigot:shadowJar`.
6. El JAR del plugin debe aparecer en `spigot/build/libs/`.
7. También puedes ejecutar la tarea raíz `shadowJar`; se ha ajustado para desempaquetar el JAR del módulo y mantener `plugin.yml` en la raíz del archivo final.

## Instalación
- Copia solo el JAR final generado a `plugins/`.
- Instala las dependencias obligatorias que indique `plugin.yml` (WolfyUtilities y NBTAPI).
- Inicia el servidor desde cero y revisa la consola. No uses PlugMan para la primera prueba.

## Importante
El ZIP original no incluye `gradle/wrapper/gradle-wrapper.jar`; por eso `gradlew` puede fallar desde consola con `GradleWrapperMain` ausente. IntelliJ puede usar una instalación local de Gradle. Si quieres usar `gradlew`, vuelve a generar/añadir el wrapper desde una instalación de Gradle.

El proyecto fue actualizado en sus referencias de versión, pero la compilación completa debe verificarse en IntelliJ con las dependencias accesibles. No se afirma que el plugin haya sido probado en un servidor real.
