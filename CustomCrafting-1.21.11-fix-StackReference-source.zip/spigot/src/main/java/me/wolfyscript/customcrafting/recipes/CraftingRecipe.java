/*
 *       ____ _  _ ____ ___ ____ _  _ ____ ____ ____ ____ ___ _ _  _ ____
 *       |    |  | [__   |  |  | |\/| |    |__/ |__| |___  |  | |\ | | __
 *       |___ |__| ___]  |  |__| |  | |___ |  \ |  | |     |  | | \| |__]
 *
 *       CustomCrafting Recipe creation and management tool for Minecraft
 *                      Copyright (C) 2021  WolfyScript
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package me.wolfyscript.customcrafting.recipes;

import com.wolfyscript.utilities.dependency.DependencySource;
import me.wolfyscript.customcrafting.CustomCrafting;
import me.wolfyscript.customcrafting.data.CCCache;
import me.wolfyscript.customcrafting.gui.main_gui.ClusterMain;
import me.wolfyscript.customcrafting.gui.recipebook.ButtonContainerIngredient;
import me.wolfyscript.customcrafting.gui.recipebook.ClusterRecipeBook;
import me.wolfyscript.customcrafting.recipes.conditions.AdvancedWorkbenchCondition;
import me.wolfyscript.customcrafting.recipes.conditions.Condition;
import me.wolfyscript.customcrafting.recipes.data.CraftingData;
import me.wolfyscript.customcrafting.recipes.items.Ingredient;
import me.wolfyscript.customcrafting.recipes.settings.CraftingRecipeSettings;
import me.wolfyscript.customcrafting.utils.CraftManager;
import me.wolfyscript.lib.com.fasterxml.jackson.annotation.JsonIgnore;
import me.wolfyscript.lib.com.fasterxml.jackson.core.JsonGenerator;
import me.wolfyscript.lib.com.fasterxml.jackson.databind.JsonNode;
import me.wolfyscript.lib.com.fasterxml.jackson.databind.SerializerProvider;
import me.wolfyscript.utilities.api.inventory.gui.GuiCluster;
import me.wolfyscript.utilities.api.inventory.gui.GuiHandler;
import me.wolfyscript.utilities.api.inventory.gui.GuiUpdate;
import me.wolfyscript.utilities.api.inventory.gui.GuiWindow;
import me.wolfyscript.utilities.api.nms.network.MCByteBuf;
import me.wolfyscript.utilities.util.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public abstract class CraftingRecipe<C extends CraftingRecipe<C, S>, S extends CraftingRecipeSettings<S>> extends CustomRecipe<C> {

    public static final String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    protected static final String INGREDIENTS_KEY = "ingredients";

    @DependencySource
    protected List<Ingredient> ingredients;

    protected final int maxGridDimension;
    protected final int maxIngredients;

    private final S settings;

    @Deprecated
    protected CraftingRecipe(NamespacedKey namespacedKey, JsonNode node, int gridSize, Class<S> settingsType) {
        super(namespacedKey, node);
        this.ingredients = List.of();
        this.maxGridDimension = gridSize;
        this.maxIngredients = maxGridDimension * maxGridDimension;
        this.settings = Objects.requireNonNullElseGet(mapper.convertValue(node.path("settings"), settingsType), () -> {
            try {
                return settingsType.getDeclaredConstructor().newInstance();
            } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                return null;
            }
        });
    }

    protected CraftingRecipe(NamespacedKey key, CustomCrafting customCrafting, int gridSize, S settings) {
        super(key, customCrafting);
        this.ingredients = List.of();
        this.maxGridDimension = gridSize;
        this.maxIngredients = maxGridDimension * maxGridDimension;
        this.settings = settings;
    }

    protected CraftingRecipe(CraftingRecipe<C, S> craftingRecipe) {
        super(craftingRecipe);
        this.ingredients = craftingRecipe.ingredients != null ? craftingRecipe.ingredients.stream().map(Ingredient::clone).toList() : List.of();
        this.maxGridDimension = craftingRecipe.maxGridDimension;
        this.maxIngredients = craftingRecipe.maxIngredients;
        this.settings = craftingRecipe.settings.clone();
    }

    @Override
    public Ingredient getIngredient(int slot) {
        return ingredients.get(slot);
    }

    @JsonIgnore
    public abstract boolean isShapeless();

    public abstract boolean fitsDimensions(CraftManager.MatrixData matrixData);

    public abstract Optional<CraftingData> checkFor(CraftManager.MatrixData matrixData);

    /**
     * @return The type specific settings. {@link me.wolfyscript.customcrafting.recipes.settings.AdvancedRecipeSettings}, {@link me.wolfyscript.customcrafting.recipes.settings.EliteRecipeSettings}
     */
    public S getSettings() {
        return settings;
    }

    /**
     * @return The max grid dimensions of the crafting recipe type.
     */
    @JsonIgnore
    public int getMaxGridDimension() {
        return maxGridDimension;
    }

    /**
     * @return The maximum ingredients of the crafting recipe type. Usually the maxGridDimension squared (9, 16, 25, 36).
     */
    @JsonIgnore
    public int getMaxIngredients() {
        return maxIngredients;
    }

    /**
     * This method returns the ingredients of the recipe. The list is unmodifiable!<br>
     * <br>
     * <b>Shaped recipe:</b><br>
     * The returned list contains the flattened ingredients, they are created from the already shrunken shape, so the list might be smaller than 9 or 36 in case of elite crafting recipes.
     * Slots that do not have an associated ingredient in the shape are filled with empty {@link Ingredient} objects.
     *
     * @return An unmodifiable list of the ingredients.
     */
    public List<Ingredient> getIngredients() {
        return ingredients;
    }

    public ItemStack[] shrinkMatrix(@Nullable Player player, @Nullable Inventory inventory, int totalAmount, CraftingData craftingData, int gridDimension) {
        ItemStack[] matrix = new ItemStack[gridDimension * gridDimension];
        craftingData.getNonNullIngredients().forEach((data) -> matrix[data.matrixSlot()] = data.reference().shrink(data.itemStack(), totalAmount, data.ingredient().isReplaceWithRemains(), inventory, player, null));
        return matrix;
    }

    @Override
    public void prepareMenu(GuiHandler<CCCache> guiHandler, GuiCluster<CCCache> cluster) {
        if (!ingredients.isEmpty()) {
            ((ButtonContainerIngredient) cluster.getButton(ButtonContainerIngredient.key(maxIngredients))).setVariants(guiHandler, this.getResult());
            for (int i = 0; i < maxIngredients && i < ingredients.size(); i++) {
                var ingredient = ingredients.get(i);
                var btn = ((ButtonContainerIngredient) cluster.getButton(ButtonContainerIngredient.key(i)));
                if (btn == null) continue;
                if (ingredient == null) {
                    btn.removeVariants(guiHandler);
                    continue;
                }
                btn.setVariants(guiHandler, ingredient);
            }
        }
    }

    @Override
    public void renderMenu(GuiWindow<CCCache> guiWindow, GuiUpdate<CCCache> event) {
        if (!ingredients.isEmpty()) {
            var cluster = guiWindow.getCluster();
            if (RecipeType.Container.CRAFTING.isInstance(this) && getConditions().has(AdvancedWorkbenchCondition.KEY)) {
                var glass = ClusterMain.GLASS_PURPLE;
                for (int i = 0; i < 9; i++) {
                    event.setButton(i, glass);
                }
                for (int i = 36; i < 54; i++) {
                    event.setButton(i, glass);
                }
            }
            List<Condition<?>> conditions = getConditions().getValues().stream().filter(condition -> !condition.getNamespacedKey().equals(AdvancedWorkbenchCondition.KEY) && !condition.getNamespacedKey().equals("permission")).toList();
            int startSlot = 9 / (conditions.size() + 1);
            int slot = 0;
            for (Condition<?> condition : conditions) {
                event.setButton(36 + startSlot + slot, new NamespacedKey(ClusterRecipeBook.KEY, "conditions." + condition.getNamespacedKey().toString("__")));
                slot += 2;
            }
            boolean elite = RecipeType.Container.ELITE_CRAFTING.isInstance(this);
            event.setButton(elite ? 24 : 23, new NamespacedKey(ClusterRecipeBook.KEY, isShapeless() ? "workbench.shapeless_on" : "workbench.shapeless_off"));
            startSlot = elite ? 0 : 10;
            for (int i = 0; i < maxIngredients; i++) {
                event.setButton(startSlot + i + (i / maxGridDimension) * (9 - maxGridDimension), ButtonContainerIngredient.key(cluster, i));
            }
            event.setButton(25, ButtonContainerIngredient.key(cluster, maxIngredients));
        }
    }

    @Deprecated
    @Override
    public void writeToJson(JsonGenerator gen, SerializerProvider serializerProvider) throws IOException {
        super.writeToJson(gen, serializerProvider);
        gen.writeObjectField(KEY_RESULT, result);
    }

    @Override
    public void writeToBuf(MCByteBuf byteBuf) {
        super.writeToBuf(byteBuf);
        byteBuf.writeInt(maxGridDimension);
        byteBuf.writeCollection(ingredients, (buf, ingredient) -> buf.writeCollection(ingredient.choices(), (buf1, reference) -> buf1.writeItemStack(reference.referencedStack())));
    }

}
