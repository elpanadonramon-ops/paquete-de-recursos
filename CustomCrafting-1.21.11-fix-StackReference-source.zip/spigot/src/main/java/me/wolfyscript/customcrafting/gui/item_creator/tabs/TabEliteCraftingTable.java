/*
 *       ____ _  _ ____ ___ ____ _  _ ____ ____ ____ ____ ___ _ _  _ ____
 *       |    |  | [__   |  |  | |\/| |    |__/ |__| |___  |  | |\ | | __
 *       |___ |__| ___]  |  |__| |  | |___ |  \ |  | |     |  | | \| |__]
 *
 *       CustomCrafting Recipe creation and management tool for Minecraft
 *                      Copyright (C) 2021  WolfyScript
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package me.wolfyscript.customcrafting.gui.item_creator.tabs;

import me.wolfyscript.customcrafting.configs.customitem.EliteCraftingTableSettings;
import me.wolfyscript.customcrafting.data.CCCache;
import me.wolfyscript.customcrafting.data.cache.items.Items;
import me.wolfyscript.customcrafting.data.cache.items.ItemsButtonAction;
import me.wolfyscript.customcrafting.gui.item_creator.ButtonOption;
import me.wolfyscript.customcrafting.gui.item_creator.MenuItemCreator;
import me.wolfyscript.customcrafting.utils.NamespacedKeyUtils;
import me.wolfyscript.utilities.api.WolfyUtilCore;
import me.wolfyscript.utilities.api.WolfyUtilities;
import me.wolfyscript.utilities.api.inventory.custom_items.CustomItem;
import me.wolfyscript.utilities.api.inventory.gui.GuiUpdate;
import me.wolfyscript.utilities.api.inventory.gui.button.ButtonState;
import me.wolfyscript.utilities.api.inventory.gui.button.buttons.DummyButton;
import me.wolfyscript.utilities.api.inventory.gui.button.buttons.MultipleChoiceButton;
import me.wolfyscript.utilities.api.inventory.gui.button.buttons.ToggleButton;
import me.wolfyscript.utilities.compatibility.plugins.ItemsAdderIntegration;
import me.wolfyscript.utilities.compatibility.plugins.itemsadder.CustomStack;
import me.wolfyscript.utilities.compatibility.plugins.itemsadder.ItemsAdderStackIdentifier;
import me.wolfyscript.utilities.util.NamespacedKey;
import me.wolfyscript.utilities.util.inventory.PlayerHeadUtils;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class TabEliteCraftingTable extends ItemCreatorTab {

    public static final String KEY = "elite_workbench";

    public TabEliteCraftingTable() {
        super(new NamespacedKey(NamespacedKeyUtils.NAMESPACE, KEY));
    }

    private static EliteCraftingTableSettings getOrCreateSettings(Items items) {
        return items.getItem().computeDataIfAbsent(EliteCraftingTableSettings.class, id -> new EliteCraftingTableSettings());
    }

    private static void changeGridSize(Items items, int gridSize) {
        getOrCreateSettings(items).setGridSize(gridSize);
    }

    private static void setEnable(Items items, boolean enable) {
        getOrCreateSettings(items).setEnabled(enable);
    }

    private static void setAdvancedRecipes(Items items, boolean advRec) {
        getOrCreateSettings(items).setAdvancedRecipes(advRec);
    }

    @Override
    public void register(MenuItemCreator creator, WolfyUtilities api) {
        creator.registerButton(new ButtonOption(Material.CRAFTING_TABLE, this));
        creator.registerButton(new DummyButton<>("elite_workbench.particles", Material.FIREWORK_ROCKET));
        new MultipleChoiceButton.Builder<>(creator, "elite_workbench.grid_size")
                .stateFunction((cache, guiHandler, player, guiInventory, i) ->
                        cache.getItems().getItem().getData(EliteCraftingTableSettings.class).map(settings -> settings.getGridSize() - 2).orElse(1))
                .addState(state -> state.subKey("size_2").icon(PlayerHeadUtils.getViaURL("9e95293acbcd4f55faf5947bfc5135038b275a7ab81087341b9ec6e453e839")).action((ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    changeGridSize(items, 3);
                    return true;
                }))
                .addState(state -> state.subKey("size_3").icon(PlayerHeadUtils.getViaURL("9e95293acbcd4f55faf5947bfc5135038b275a7ab81087341b9ec6e453e839")).action((ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    changeGridSize(items, 4);
                    return true;
                }))
                .addState(state -> state.subKey("size_4").icon(PlayerHeadUtils.getViaURL("cbfb41f866e7e8e593659986c9d6e88cd37677b3f7bd44253e5871e66d1d424")).action((ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    changeGridSize(items, 5);
                    return true;
                }))
                // Deprecated states
                .addState(state -> state.subKey("size_5").icon(PlayerHeadUtils.getViaURL("14d844fee24d5f27ddb669438528d83b684d901b75a6889fe7488dfc4cf7a1c")).action((ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    changeGridSize(items, 6);
                    return true;
                }))
                .addState(state -> state.subKey("size_6").icon(PlayerHeadUtils.getViaURL("faff2eb498e5c6a04484f0c9f785b448479ab213df95ec91176a308a12add70")).action((ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    changeGridSize(items, 2);
                    return true;
                })).register();
        creator.registerButton(new ToggleButton<>("elite_workbench.toggle", (cache, guiHandler, player, guiInventory, i) ->
                cache.getItems().getItem().getData(EliteCraftingTableSettings.class).map(EliteCraftingTableSettings::isEnabled).orElse(false),
                new ButtonState<>("elite_workbench.toggle.enabled", Material.GREEN_CONCRETE, (ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    setEnable(items, false);
                    return true;
                }),
                new ButtonState<>("elite_workbench.toggle.disabled", Material.RED_CONCRETE, (ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    setEnable(items, true);
                    return true;
                })));
        creator.registerButton(new ToggleButton<>("elite_workbench.advanced_recipes", (cache, guiHandler, player, guiInventory, i) ->
                cache.getItems().getItem().getData(EliteCraftingTableSettings.class).map(EliteCraftingTableSettings::isAdvancedRecipes).orElse(false),
                new ButtonState<>("elite_workbench.advanced_recipes.enabled", Material.GREEN_CONCRETE, (ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    setAdvancedRecipes(items, false);
                    return true;
                }),
                new ButtonState<>("elite_workbench.advanced_recipes.disabled", Material.RED_CONCRETE, (ItemsButtonAction) (cache, items, guiHandler, player, inventory, i, event) -> {
                    setAdvancedRecipes(items, true);
                    return true;
                })));
    }

    @Override
    public boolean shouldRender(GuiUpdate<CCCache> update, CCCache cache, Items items, CustomItem customItem, ItemStack item) {
        return item.getType().isBlock() ||
                (
                        customItem.stackReference().identifier().orElse(null) instanceof ItemsAdderStackIdentifier iaRef &&
                                ((WolfyUtilCore) update.getGuiHandler().getWolfyUtils().getCore()).getCompatibilityManager().getPlugins().evaluateIfAvailable("ItemsAdder", ItemsAdderIntegration.class, ia -> ia.getStackInstance(iaRef.itemId()).map(CustomStack::isBlock).orElse(false))
                );
    }

    @Override
    public void render(GuiUpdate<CCCache> update, CCCache cache, Items items, CustomItem customItem, ItemStack item) {
        update.setButton(28, "elite_workbench.particles");
        update.setButton(30, "elite_workbench.grid_size");
        update.setButton(32, "elite_workbench.toggle");
        update.setButton(34, "elite_workbench.advanced_recipes");
    }
}
