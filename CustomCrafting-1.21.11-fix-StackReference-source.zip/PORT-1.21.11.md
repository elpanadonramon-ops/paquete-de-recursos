# Port preliminar a Minecraft 1.21.11

Este árbol parte del código fuente CustomCrafting 4.19.1.0 y actualiza la versión objetivo de Paper a 1.21.11.

## Cambios realizados
- `gradle/libs.versions.toml`: Paper API `1.21.11-R0.1-SNAPSHOT`.
- `spigot/src/main/resources/plugin.yml`: `api-version: "1.21.11"`.
- `build.gradle.kts`: servidores de prueba y metadatos de versiones actualizados a 1.21.11.

## Importante: compilación pendiente de verificación
No se pudo ejecutar Gradle en el entorno donde se preparó este archivo: el ZIP original no contiene `gradle/wrapper/gradle-wrapper.jar` y el entorno no pudo descargar Gradle por falta de acceso de red. Por eso este paquete **no debe considerarse una compilación verificada ni una garantía de compatibilidad en ejecución**. Cambiar la versión de Paper y `api-version` no reemplaza la revisión de incompatibilidades de código.

Además, este proyecto depende de `wolfyutils-spigot:4.19-SNAPSHOT`, publicado en el repositorio de WolfyScript. Si esa dependencia no resuelve o contiene referencias incompatibles con Paper 1.21.11, habrá que adaptar esas clases/dependencias también.

## Compilar en IntelliJ IDEA
1. Abre la carpeta raíz del proyecto como proyecto Gradle.
2. Configura un JDK 21.
3. Si el wrapper falla por faltar `gradle-wrapper.jar`, selecciona una instalación local de Gradle 8.13 o regenera el wrapper desde una terminal con Gradle instalado: `gradle wrapper --gradle-version 8.13`.
4. Ejecuta `:spigot:compileJava` primero y después `build`/`shadowJar`.
5. Comparte el primer error de compilación que aparezca; servirá para corregir las incompatibilidades reales en lugar de ocultarlas.

No subas el plugin a un servidor de producción sin probar recetas, GUIs, guardado/carga de datos y las integraciones externas.
