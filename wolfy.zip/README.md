<div align="center"><img src="https://github.com/WolfyScript/WolfyUtilities/assets/41468455/f6c49bf5-313d-4a1f-856a-e0a212570c04" alt="WolfyUtilities Banner" /></div>

## WolfyUtils-Spigot
![bstats_server](https://img.shields.io/bstats/servers/5114?label=Servers)  
![spigot_down](https://img.shields.io/spiget/downloads/64124?label=Spigot+Downloads)
![spigot_stars](https://img.shields.io/spiget/stars/64124?label=Spigot+Rating)  
![github_commit](https://img.shields.io/github/last-commit/WolfyScript/WolfyUtils-Spigot)


Core API that provides an API and Utils for plugins based on Spigot.

> [!NOTE]  
> **WolfyUtils is still maintained, but it will be replaced by the more modern [scafall](https://github.com/WolfyScript/scafall) project in the future!**  
> While scafall is in development this project will still receive bug fixes and Minecraft compatibility updates.  
> Major feature updates should not be expected! New features will be implemented in scafall instead!  
> **There is no ETA for scafall!** *Since scafall is still in alpha, it will be a while till it's stable!*

### APIs & Utils
- **API** is plugin dependent, which means there is one instance of the API per plugin.
- **Utils** are plugin independent. They can be used everywhere.
- **Registry** is bound to the core of WolfyUtilities, but can be accessed from anywhere.

#### APIs
- **Inventory** - Functional API to create in-game GUIs.
- **Language** - Load JSON based language files and support multiple languages for GUIs, messages, etc.
- **Chat** - Send translatable messages, text click event callbacks, and more.
    - (**3.16.1+**) [KyoriPowered/adventure](https://github.com/KyoriPowered/adventure) implementation.
- **Config** - Simple config utilities.
- **NMS** - Fully featured **NBTTag API**, custom **RecipeIterator**, and some block and Inventory Utils.
- **CustomItems** - Create flexible custom items with settings like custom fuel, durability, actions, etc.

#### Registry
The Registry is the base of all custom content in WolfyUtilities and the plugins that build on it.
It allows you to register types & objects under unique namespaced keys.
That not only allows the plugin to register things like CustomItems, etc., but it can be extended by other plugins too.

#### Utils:
- **NamespacedKey** - Unique key for all registrable content.
- **JSON** - Various Jackson utils that simplify de-/serialization
    - Custom de-/serializer for Bukkit objects
    - Easy de-/serialization from Registry values
        - Object  (See @OptionalKeyReference)
        - Type to object (See @KeyedTypeIdResolver & @KeyedTypeResolver)
- **Particles** - Configure custom particle effects & animations using JSON.
- **RandomCollection** - Weight based random collection.
- **Reflection** - Basic Reflection Utils.
- **Player Head** utils to set textures and more.
- Basic **MySQL** connection to run queries and updates.
- ItemBuilder to edit/create ItemStacks.
- Save player specific data.

### Plugins using WolfyUtilities

#### CustomCrafting
CustomCrafting is heavily based on these APIs and Utils, and is more of an extension than standalone plugin.  
CustomCrafting especially makes use of the InventoryAPI to create and manage the in-game RecipeCreators.
The JSON utils are used to load/save recipes & items from/to JSON, and to allow for custom settings inside the json files.

# Getting started

You can get the API from the public maven repo:

```xml
<repositories>
    <repository>
        <id>wolfyscript-public</id>
        <url>https://maven.wolfyscript.com/repository/public/</url>
    </repository>
</repositories>
```

```xml
<dependencies>
    <dependency>
        <groupId>com.wolfyscript.wolfyutilities</groupId>
        <artifactId>wolfyutilities</artifactId>
        <version>3.16.1.0</version>
        <scope>provided</scope>
    </dependency>
</dependencies>
```

To start using it you need to create an API instance for your plugin.<br>
It's best to initiate it in your constructor, so you don't mistakenly change the instance of the api.
(And we are able to use some options of the API **onLoad()**)

```java

import me.wolfyscript.lib.net.kyori.adventure.text.Component;

public class YourPlugin extends JavaPlugin {

  private final WolfyUtilities api;

  public YourPlugin() {
    super();
    //Create the instance for your plugin. We don't want to initialize the events yet (so set it to false)!
    api = WolfyUtilCore.getInstance().getAPI(this, false);
    this.chat = api.getChat();
    //We should set our prefix for the chat
    this.chat.setChatPrefix(Component.text("[", NamedTextColor.GRAY).append(Component.text("CC", NamedTextColor.AQUA))
            .append(Component.text("] ", NamedTextColor.DARK_GRAY)));
    //Or using the MiniMessage api
    this.chat.setChatPrefix(chat.getMiniMessage().parse("<gray>[<gradient:dark_aqua:aqua>CC</gradient><gray>]"));

    //Optionally you can set a custom cache object to cache data for your GUI.
    api.setInventoryAPI(new InventoryAPI<>(api.getPlugin(), api, CCCache.class));
  }

  @Override
  public void onEnable() {
    //Once the plugin is enabled we can initialize the events!
    this.api.initialize();
  }

}

```

More info about the API can be found in the [Wiki](https://github.com/WolfyScript/WolfyUtilities/wiki).
<br>


## Port de compatibilidad para Minecraft 1.21.11

Este paquete actualiza la versión objetivo de Paper API, los servidores de prueba y los metadatos de publicación a Minecraft 1.21.11. El código fuente original se conserva; esta actualización de configuración no sustituye una compilación y prueba real en un servidor 1.21.11.

### Compilar en IntelliJ IDEA

1. Instala/selecciona un JDK 21.
2. Abre la carpeta raíz que contiene `settings.gradle.kts`.
3. Si IntelliJ indica que falta `gradle-wrapper.jar`, selecciona una instalación local de Gradle 8.13 o genera el wrapper desde una terminal donde Gradle esté instalado (`gradle wrapper --gradle-version 8.13`).
4. Recarga el proyecto Gradle y ejecuta `shadowJar`.
5. El artefacto esperado es `build/libs/wolfyutils-spigot-4.19.1.2.jar` (el nombre exacto puede variar según la configuración Gradle).
6. Prueba el resultado en un servidor de prueba Paper/Purpur 1.21.11 antes de usarlo en producción.

**Importante:** el ZIP original no incluía `gradle/wrapper/gradle-wrapper.jar`. Tampoco se ha podido ejecutar una compilación de verificación en este entorno. Si Gradle detecta errores de API o dependencias al compilar, esos errores deben corregirse antes de considerar el port terminado.
